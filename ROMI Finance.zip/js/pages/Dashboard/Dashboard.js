import React from "react";

import DashboardV2 from "./DashboardV2";

export default function Dashboard(props) {
    return <DashboardV2 / > ;
}