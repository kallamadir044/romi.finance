export const REDIRECT_POPUP_TIMESTAMP_KEY = "redirect-popup-timestamp";

export const IS_TOUCH = "ontouchstart" in window;

export const UI_VERSION = "1.4";

export const TRIGGER_PREFIX_ABOVE = ">";
export const TRIGGER_PREFIX_BELOW = "<";
